import React from "react";

export default function LoginPage() {
  return (
    <div className="flex justify-center items-center min-h-screen">
      <div className="bg-purple-700 p-8 rounded-2xl w-full max-w-md shadow-xl">
        <h2 className="text-white text-2xl font-bold mb-6 text-center">ورود / ثبت‌نام</h2>
        <input className="w-full p-3 mb-4 rounded-xl" placeholder="ایمیل" />
        <input type="password" className="w-full p-3 mb-4 rounded-xl" placeholder="رمز عبور" />
        <button className="w-full bg-black text-white py-3 rounded-xl">ورود</button>
      </div>
    </div>
  );
}
